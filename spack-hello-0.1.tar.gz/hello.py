# -----------------------------------------------------
# (C) 2020 Frank Hofmann <frank.hofmann@efho.de>
#
# hello-spack. A Hello, world! in Python in order 
# to test the SPACK package manager (http://spack.io/)
#
# Published unter BSD License.
# -----------------------------------------------------

print("Hello, world!")
